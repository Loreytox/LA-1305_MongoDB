﻿using MongoDB.Driver;
using System;
using System.Collections.Generic;

namespace FunnyJokes
{
    class Program
    {
        private static IMongoCollection<Joke> jokeCollection;

        static void Main(string[] args)
        {
            try
            {
                // Setup MongoDB connection
                var client = new MongoClient("mongodb://localhost:27017");
                var database = client.GetDatabase("Funny");
                jokeCollection = database.GetCollection<Joke>("Jokes");

                // Main application loop
                while (true)
                {
                    Console.WriteLine("Enter the joke type you want to see (dark humor, light humor, dad joke, dumb joke) or 'exit' to quit:");
                    var input = Console.ReadLine()?.Trim().ToLower();

                    if (input == "exit")
                    {
                        break;
                    }

                    var jokes = GetJokesByType(input);
                    if (jokes.Count == 0)
                    {
                        Console.WriteLine("No jokes found for this type.");
                        continue;
                    }

                    foreach (var joke in jokes)
                    {
                        Console.WriteLine($"Joke: {joke.Content}");
                        Console.WriteLine("Options: [view new joke / delete / update / exit]");
                        var option = Console.ReadLine()?.Trim().ToLower();

                        if (option == "delete")
                        {
                            DeleteJoke(joke.Id);
                            Console.WriteLine("Joke deleted.");
                        }
                        else if (option == "update")
                        {
                            Console.WriteLine("Enter the new joke:");
                            var newJoke = Console.ReadLine();
                            UpdateJoke(joke.Id, newJoke);
                            Console.WriteLine("Joke updated.");
                        }
                        else if (option == "exit")
                        {
                            return;
                        }
                        else if (option == "view new joke")
                        {
                            continue;
                        }
                        else
                        {
                            Console.WriteLine("Invalid option. Please try again.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred: {ex.Message}");
            }
        }

        private static List<Joke> GetJokesByType(string type)
        {
            try
            {
                var filter = Builders<Joke>.Filter.Eq("Type", type);
                return jokeCollection.Find(filter).ToList();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error retrieving jokes: {ex.Message}");
                return new List<Joke>();
            }
        }

        private static void DeleteJoke(string id)
        {
            try
            {
                var filter = Builders<Joke>.Filter.Eq("Id", id);
                var result = jokeCollection.DeleteOne(filter);

                if (result.DeletedCount == 0)
                {
                    Console.WriteLine("Joke not found or already deleted.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error deleting joke: {ex.Message}");
            }
        }

        private static void UpdateJoke(string id, string newJoke)
        {
            try
            {
                var filter = Builders<Joke>.Filter.Eq("Id", id);
                var update = Builders<Joke>.Update.Set("JokeContent", newJoke);
                var result = jokeCollection.UpdateOne(filter, update);

                if (result.ModifiedCount == 0)
                {
                    Console.WriteLine("Joke not found or no changes made.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error updating joke: {ex.Message}");
            }
        }
    }
}
