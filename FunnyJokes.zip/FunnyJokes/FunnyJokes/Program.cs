﻿using FunnyJokes;
using MongoDB.Driver;
using System;
using System.Collections.Generic;

namespace FunnyJokes
{
    class Program
    {
        private static IMongoCollection<Joke> jokeCollection;

        static void Main(string[] args)
        {
            // Setup MongoDB connection
            var client = new MongoClient("mongodb://localhost:27017");
            var database = client.GetDatabase("Funny");
            jokeCollection = database.GetCollection<Joke>("Jokes");

            // Main application loop
            while (true)
            {
                Console.WriteLine("Enter the joke type you want to see (dark humor, light humor, dad joke, dumb joke) or 'exit' to quit:");
                var input = Console.ReadLine();

                if (input.ToLower() == "exit")
                {
                    break;
                }

                var jokes = GetJokesByType(input);
                if (jokes.Count == 0)
                {
                    Console.WriteLine("No jokes found for this type.");
                    continue;
                }

                foreach (var joke in jokes)
                {
                    Console.WriteLine($"Joke: {joke.Content}");
                    Console.WriteLine("Options: [view new joke / delete / update / exit]");
                    var option = Console.ReadLine();

                    if (option.ToLower() == "delete")
                    {
                        DeleteJoke(joke.Id);
                        Console.WriteLine("Joke deleted.");
                    }
                    else if (option.ToLower() == "update")
                    {
                        Console.WriteLine("Enter the new joke:");
                        var newJoke = Console.ReadLine();
                        UpdateJoke(joke.Id, newJoke);
                        Console.WriteLine("Joke updated.");
                    }
                    else if (option.ToLower() == "exit")
                    {
                        return;
                    }
                }
            }
        }

        private static List<Joke> GetJokesByType(string type)
        {
            var filter = Builders<Joke>.Filter.Eq("type", type);
            return jokeCollection.Find(filter).ToList();
        }

        private static void DeleteJoke(string id)
        {
            var filter = Builders<Joke>.Filter.Eq("Id", id);
            jokeCollection.DeleteOne(filter);
        }

        private static void UpdateJoke(string id, string newJoke)
        {
            var filter = Builders<Joke>.Filter.Eq("Id", id);
            var update = Builders<Joke>.Update.Set("joke", newJoke);
            jokeCollection.UpdateOne(filter, update);
        }
    }
}
